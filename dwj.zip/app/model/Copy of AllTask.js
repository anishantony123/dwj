Ext.define('Rims.model.AllTask',{
	extend:'Ext.data.Model',
	config:{
		fields:['incidentId','summary','severity']
		}
	});