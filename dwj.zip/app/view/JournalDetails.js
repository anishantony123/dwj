Ext.define('radiss.view.JournalDetails',{
	extend:'Ext.Container',
	xtype:'journaldetails',
	fullscreen:true,
	
	html:'test data goes heree ..',
	config:{		
		
		title:'Journal Details',
		}
	}
	);